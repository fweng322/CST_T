﻿//*****************************************************
// 題庫
//*****************************************************
//每一題庫包括兩部份(欄位) : 選單及短文
//	1.中括號的左括號下第一行為選單標題 
//	2.function() 的下一行為短文內容
//
menuItemAndTextLines= new Array(

[
"第一關(英)",
	function(){/*--這一行請勿更改--
Head, shoulders, knees, and toes,
Knees and toes,
Head, shoulders, knees, and toes,
Knees and toes,
Eyes, and ears and mouth and nose,
Head, shoulders, knees and toes,
Knees and toes.
-----*/}.toString().slice("function(){/*--這一行請勿更改--".length+2,-9)
]

,	//本逗號之後為下一個選單的內容, 所以新增別忘了加逗號

[
"第二關(英)",
	function(){/*--這一行請勿更改--
I have a pen, I have an apple.
Oh! apple pen.
I have a pen, I have a pineapple.
Oh! pineapple pen.
Apple pen, pineapple pen.
OH! pen pineapple apple pen
-----*/}.toString().slice("function(){/*--這一行請勿更改--".length+2,-9)
]

,	//本逗號之後為下一個選單的內容, 所以新增別忘了加逗號

[
"第三關(中)",
	function(){/*--這一行請勿更改--
永和有永和路，中和有中和路，
中和的中和路有接永和的中和路，
永和的永和路沒接中和的永和路；
永和的中和路有接永和的永和路，
中和的永和路沒接中和的中和路。
-----*/}.toString().slice("function(){/*--這一行請勿更改--".length+2,-9)
]

,	//本逗號之後為下一個選單的內容, 所以新增別忘了加逗號

[
"第四關(中)",
	function(){/*--這一行請勿更改--
化肥會揮發。黑化肥發灰，灰化肥發黑。
黑化肥發灰會揮發；灰化肥揮發會發黑。
黑化肥揮發發灰會花飛；灰化肥揮發發黑會飛花。
黑灰化肥會揮發發灰黑諱為花飛；
灰黑化肥會揮發發黑灰為諱飛花。
黑灰化肥灰會揮發發灰黑諱為黑灰花會飛；
灰黑化肥會會揮發發黑灰為諱飛花化為灰。
-----*/}.toString().slice("function(){/*--這一行請勿更改--".length+2,-9)
]

);	//********************題庫結束*****************************

//*****************************************************
//
//*****************************************************
text_compression.textFontSize = 40;		//文字字型大小
text_compression.caseSensitive = false;	//是否區分大小寫

//messages
text_compression.messageButtonPatternSelect = '開始選取保留目標';
text_compression.messageButtonPatternOk = '保留標的選取完成';
text_compression.messageButtonTargetSelect = '開始選取壓縮標的';
text_compression.messageButtonTargetOk = '壓縮標的選取完成';
text_compression.messageButtonCompressStart = '點擊開始壓縮';
text_compression.messageButtonCompressOk = '繼續進行';

text_compression.messageButtonFinish = '全部完成';

text_compression.messageResultCaption = '壓縮結果';
text_compression.messageResultButtonOk = '回主選單';
text_compression.messageResultPrefix = '總共用了 ';
text_compression.messageResultMiddle = ' 個壓縮步驟；壓縮了 ';
text_compression.messageResultPostfix = ' 個字元';
text_compression.messageDelayResult = 3000;

text_compression.messagePatternSelectErr1 = '至少要選取 2 個字元';
text_compression.messagePatternSelectErr2 = '標的必須連續選取，請勿跨字';
text_compression.messageDelayPatternSelectErr = 2;
