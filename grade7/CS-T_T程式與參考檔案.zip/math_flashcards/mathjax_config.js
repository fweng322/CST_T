//-----------------------------------------------
// MathJax Config
//-----------------------------------------------
window.MathJax = {
	jax: ["input/TeX","output/HTML-CSS"], 
	extensions: ["tex2jax.js"],
	//displayAlign: "left",
	tex2jax: { 
		inlineMath: [['$','$'],['\\(','\\)']]
	},
	SVG: {
		scale: 100,
		width: '800px'
	}
};

//-----------------------------------------------
// Load MathJax from where
//-----------------------------------------------
mathJaxURL = 'https://cdn.mathjax.org/mathjax/latest/MathJax.js';

